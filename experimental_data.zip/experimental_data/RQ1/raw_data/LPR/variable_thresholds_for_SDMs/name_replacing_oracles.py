import os

# 设置文件目录路径
directory= os.path.dirname(os.path.abspath(__file__))   
print(directory)
# 定义需要替换的目标字符串和替换字符串
old_string_list = ['Square', 'JS Dist', 'U Test', 'CE Dist']  # 你要替换的字符串
new_string_list = ['Squared', 'JS Div', 'MW Test', 'Crs Ent']  # 替换成的字符串

for i in range(len(old_string_list)):
    old_string = old_string_list[i]
    new_string = new_string_list[i]
    # 获取文件夹内所有的文件
    for filename in os.listdir(directory):
        # 检查文件扩展名是否为.csv
        if filename.endswith('.csv'):
            # 构造文件的完整路径
            old_file_path = os.path.join(directory, filename)
            
            # 如果文件名中包含指定的字符串，进行替换
            if old_string in filename:
                # 新的文件名
                new_filename = filename.replace(old_string, new_string)
                new_file_path = os.path.join(directory, new_filename)
                
                # 重命名文件
                os.rename(old_file_path, new_file_path)
                print(f'Renamed: {filename} -> {new_filename}')
